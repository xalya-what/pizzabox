this game was made by xalya and living cheese.
this game is NOT actually a teaching game but something similar to baldis bascis
i hope you enjoy this game i have been working on a while...
check out my youtube channel https://www.youtube.com/@Xalya_insanity
check out living cheese youtube channel https://www.youtube.com/@living_cheese
hope you don't anger pizzabox... because if you do... it will delete your game.
do not harass pizzabox he is just your computer.
there are a lot of hidden secrets i hope you can find them.
and remember that ilikeeatingpizza.
also if you by chance stumble upon "your player" and you want your pc to not be infected
then i advice you to close the game and start another one.
same goes when you anger pizzabox so much by trying to escape from hard mode.
insane mode will start.
and will wipe anything you ever hard on your personal computer.
also..
DISCLAIMER: this game is a trojan game. meaning that this game will damage or destroy
your system if you do something it doesn't want you to do.
remember that i am just warning you about the causes this program could do to your computer
so don't be too shocked if you will need to re-install windows after this.